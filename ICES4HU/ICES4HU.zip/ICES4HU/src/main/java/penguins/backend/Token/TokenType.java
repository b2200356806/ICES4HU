package penguins.backend.Token;

public enum TokenType {
    BEARER
}
