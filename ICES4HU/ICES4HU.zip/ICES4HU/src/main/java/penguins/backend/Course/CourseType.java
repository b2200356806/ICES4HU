package penguins.backend.Course;

public enum CourseType {
    UNDERGRADUATE,
    GRADUATE
}
